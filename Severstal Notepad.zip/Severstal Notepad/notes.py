import sys, os
from PyQt5.QtWidgets import (QApplication, QMainWindow, QWidget, 
                             QPushButton, QLabel, QPlainTextEdit, QStatusBar, QToolBar, 
                             QVBoxLayout, QAction, QFileDialog, QMessageBox)
from PyQt5.QtCore import Qt, QSize                          
from PyQt5.QtGui import QFontDatabase, QIcon, QKeySequence, QTextDocument
from PyQt5.QtPrintSupport import QPrintDialog


class App(QMainWindow):
    def __init__(self):
        super().__init__() 
        
        #Блок настроек параметров окна 
        self.setWindowTitle('Severstal Notepad')
        self.setWindowIcon(QIcon(r'.\icons\main_icon.svg'))
        self.resize(self.geometry().width() * 2, self.geometry().height() * 2)
        
        # Допустимые форматы заметок. Используятся только .txt
        self.fileTypes = 'Text Document (*.txt)'
        
        self.path = None
        
        # 
        
        fixedFont = QFontDatabase.systemFont(QFontDatabase.FixedFont)
        fixedFont.setPointSize(12)

        mainLayout = QVBoxLayout()

        # Создание окна для ввода текста
        self.editor = QPlainTextEdit('Данное приложение позволяет создавать текстовые заметки и сохранять их в формате .txt')
        self.editor.setFont(fixedFont)
        mainLayout.addWidget(self.editor)
        
        

        self.statusBar = self.statusBar()

        # Контейнер
        container = QWidget()
        container.setLayout(mainLayout)
        self.setCentralWidget(container)
        
        # Создание вкладки 'Заметка' на в меню приложения
        file_menu = self.menuBar().addMenu('&Заметка')

        # Создание вкладки 'Заметка' на панели задач приложения

        file_toolbar = QToolBar('Заметка')
        file_toolbar.setIconSize(QSize(60, 60))
        self.addToolBar(Qt.BottomToolBarArea, file_toolbar)

    
        
   
        
        # Открытие и сохранение
        
        open_file_action = self.create_action(self, r'.\icons\note.svg', 'Открыть заметку', 'Открыть заметку', self.file_open)
        open_file_action.setShortcut(QKeySequence.Open)
        
        save_file_action = self.create_action(self, r'.\icons\save.svg', 'Сохранить заметку', 'Сохранить заметку', self.file_save)
        save_file_action.setShortcut(QKeySequence.Save)

        file_menu.addActions([open_file_action, save_file_action])
        file_toolbar.addActions([open_file_action, save_file_action])
        
        
    # Методы открытия, сохранения и диалогового окна
    
    def create_action(self, parent, icon_path, action_name, set_status_tip, triggered_method):
        action = QAction(QIcon(icon_path), action_name, parent)
        action.setStatusTip(set_status_tip)
        action.triggered.connect(triggered_method)
        return action
        
    def dialog_message(self, message):
        dlg = QMessageBox(self)
        dlg.setText(message)
        dlg.setIcon(QMessageBox.Critical)
        dlg.show()
        
        
    def file_open(self):
        path, _ = QFileDialog.getOpenFileName(
            parent=self,
            caption='Открыть заметку',
            directory='',
            filter=self.fileTypes
        )

        if path:
            try:    
                with open(path, 'r') as f:
                    text = f.read()
                    f.close()
            except Exception as e:
                self.dialog_message(str(e))
            else:
                self.path = path
                self.editor.setPlainText(text)
                
                
    # Метод для первичного сохранения         

    def file_saveAs(self):
        path, _ = QFileDialog.getSaveFileName(
            self,
            'Сохранить как',
            '',
            self.fileTypes
        )                               

        text = self.editor.toPlainText()

        if not path:
            return
        else:
            try:
                with open(path, 'w') as f:
                    f.write(text)
                    f.close()
            except Exception as e:
                self.dialog_message(str(e))
            else:
                self.path = path
    
    # Метод для повторного сохранения 
    
    def file_save(self):
        if self.path is None:
            self.file_saveAs()
        else:
            try:
                text = self.editor.toPlainText()
                with open(self.path, 'w') as f:
                    f.write(text)
                    f.close()
            except Exception as e:  
                self.dialog_message(str(e))
            
            
    
        
app = QApplication(sys.argv)
severstal_notepad = App()
severstal_notepad.show()
sys.exit(app.exec_())